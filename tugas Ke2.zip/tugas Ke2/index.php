
<!DOCTYPE html>
<html>
<head>
    <title>Encryption and Decryption Program</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        .container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        label {
            display: block;
            margin-bottom: 5px;
        }
        textarea {
            width: 100%;
            height: 100px;
            resize: vertical;
        }
        .result {
            margin-top: 10px;
            font-weight: bold;
        }
    </style>
</head>
<body>
<div class="container">
        <h2>Encryption and Decryption Program</h2>
        <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>" enctype="multipart/form-data">
            <label for="plaintext">Plaintext:</label>
            <textarea id="plaintext" name="plaintext"><?php echo isset($_POST['plaintext']) ? $_POST['plaintext'] : ''; ?></textarea>

            <label for="file">Choose a file:</label>
            <input type="file" id="file" name="file">

            <label for="key">Key:</label>
            <input type="text" id="key" name="key" value="<?php echo isset($_POST['key']) ? $_POST['key'] : ''; ?>">

            <label for="cipherType">Cipher Type:</label>
            <select id="cipherType" name="cipherType">
                <option value="vigenere" <?php echo isset($_POST['cipherType']) && $_POST['cipherType'] === 'vigenere' ? 'selected' : ''; ?>>Vigenere Cipher</option>
                <option value="playfair" <?php echo isset($_POST['cipherType']) && $_POST['cipherType'] === 'playfair' ? 'selected' : ''; ?>>Playfair Cipher</option>
                <option value="extendedVigenere" <?php echo isset($_POST['cipherType']) && $_POST['cipherType'] === 'extendedVigenere' ? 'selected' : ''; ?>>Extended Vigenere Cipher</option>
            </select>

            <label for="action">Action:</label>
            <select id="action" name="action">
                <option value="encrypt" <?php echo isset($_POST['action']) && $_POST['action'] === 'encrypt' ? 'selected' : ''; ?>>Encrypt</option>
                <option value="decrypt" <?php echo isset($_POST['action']) && $_POST['action'] === 'decrypt' ? 'selected' : ''; ?>>Decrypt</option>
            </select>

            <input type="submit" name="submit" value="Submit">
        </form>

        <?php
        error_reporting(0);
        if ($_SERVER["REQUEST_METHOD"] == "POST") {

            function prepareKey($key, $cipherType) {
                $key = strtoupper($key);
                $key = preg_replace('/[^A-Z]/', '', $key);

                if ($cipherType === 'playfair') {
                    $key = str_replace('J', 'I', $key);
                }

                return $key;
            }

            function vigenereEncrypt($plaintext, $key) {
                $key = prepareKey($key, 'vigenere');
                $keyLength = strlen($key);
                $plaintext = strtoupper($plaintext);

                $ciphertext = '';
                for ($i = 0; $i < strlen($plaintext); $i++) {
                    $char = $plaintext[$i];
                    if (ctype_alpha($char)) {
                        $offset = ord('A');
                        $keyChar = $key[$i % $keyLength];
                        $keyIndex = ord($keyChar) - $offset;
                        $charIndex = ord($char) - $offset;
                        $encryptedChar = chr(($charIndex + $keyIndex) % 26 + $offset);
                        $ciphertext .= $encryptedChar;
                    }
                }

                return $ciphertext;
            }

            function vigenereDecrypt($ciphertext, $key) {
                $key = prepareKey($key, 'vigenere');
                $keyLength = strlen($key);
                $ciphertext = strtoupper($ciphertext);

                $plaintext = '';
                for ($i = 0; $i < strlen($ciphertext); $i++) {
                    $char = $ciphertext[$i];
                    if (ctype_alpha($char)) {
                        $offset = ord('A');
                        $keyChar = $key[$i % $keyLength];
                        $keyIndex = ord($keyChar) - $offset;
                        $charIndex = ord($char) - $offset;
                        $decryptedChar = chr(($charIndex - $keyIndex + 26) % 26 + $offset);
                        $plaintext .= $decryptedChar;
                    }
                }

                return $plaintext;
            }
            function getPlayfairLetterCoordinates($letter, $matrix) {
                for ($i = 0; $i < 5; $i++) {
                    for ($j = 0; $j < 5; $j++) {
                        if ($matrix[$i][$j] === $letter) {
                            return array($i, $j);
                        }
                    }
                }
                return null;
            }

            function handleSameRow($row, $col1, $col2, $direction, $matrix) {
                $newCol1 = ($col1 + $direction + 5) % 5;
                $newCol2 = ($col2 + $direction + 5) % 5;
                return $matrix[$row][$newCol1] . $matrix[$row][$newCol2];
            }

            function handleSameColumn($col, $row1, $row2, $direction, $matrix) {
                $newRow1 = ($row1 + $direction + 5) % 5;
                $newRow2 = ($row2 + $direction + 5) % 5;
                return $matrix[$newRow1][$col] . $matrix[$newRow2][$col];
            }

            function playfairEncrypt($plaintext, $matrix) {
                $plaintext = strtoupper(preg_replace('/[^A-Z]/', '', str_replace('J', 'I', $plaintext)));
                $ciphertext = '';

                $length = strlen($plaintext);
                $i = 0;

                while ($i < $length) {
                    $char1 = $plaintext[$i];
                    $char2 = '';

                    if ($i + 1 === $length || $char1 === $plaintext[$i + 1]) {
                        $char2 = 'X';
                        $i--;
                    } else {
                        $char2 = $plaintext[$i + 1];
                    }

                    list($row1, $col1) = getPlayfairLetterCoordinates($char1, $matrix);
                    list($row2, $col2) = getPlayfairLetterCoordinates($char2, $matrix);

                    if ($row1 === $row2) {
                        $ciphertext .= handleSameRow($row1, $col1, $col2, 1, $matrix);
                    } elseif ($col1 === $col2) {
                        $ciphertext .= handleSameColumn($col1, $row1, $row2, 1, $matrix);
                    } else {
                        $ciphertext .= $matrix[$row1][$col2] . $matrix[$row2][$col1];
                    }

                    $i += 2;
                }

                return $ciphertext;
            }

            function playfairDecrypt($ciphertext, $matrix) {
                $ciphertext = strtoupper(preg_replace('/[^A-Z]/', '', str_replace('J', 'I', $ciphertext)));
                $plaintext = '';

                $length = strlen($ciphertext);
                $i = 0;

                while ($i < $length) {
                    $char1 = $ciphertext[$i];
                    $char2 = $ciphertext[$i + 1];

                    list($row1, $col1) = getPlayfairLetterCoordinates($char1, $matrix);
                    list($row2, $col2) = getPlayfairLetterCoordinates($char2, $matrix);

                    if ($row1 === $row2) {
                        $plaintext .= handleSameRow($row1, $col1, $col2, -1, $matrix);
                    } elseif ($col1 === $col2) {
                        $plaintext .= handleSameColumn($col1, $row1, $row2, -1, $matrix);
                    } else {
                        $plaintext .= $matrix[$row1][$col2] . $matrix[$row2][$col1];
                    }

                    $i += 2;
                }

                return $plaintext;
            }





            // ... (existing functions for Vigenere and Playfair ciphers) ...

            function extendedVigenereEncrypt($plaintext, $key) {
                $key = prepareKey($key, 'vigenere');
                $keyLength = strlen($key);
                $ciphertext = '';

                for ($i = 0; $i < strlen($plaintext); $i++) {
                    $char = $plaintext[$i];
                    $keyChar = $key[$i % $keyLength];
                    $encryptedChar = chr((ord($char) + ord($keyChar)) % 256);
                    $ciphertext .= $encryptedChar;
                }

                return $ciphertext;
            }

            function extendedVigenereDecrypt($ciphertext, $key) {
                $key = prepareKey($key, 'vigenere');
                $keyLength = strlen($key);
                $plaintext = '';

                for ($i = 0; $i < strlen($ciphertext); $i++) {
                    $char = $ciphertext[$i];
                    $keyChar = $key[$i % $keyLength];
                    $decryptedChar = chr((ord($char) - ord($keyChar) + 256) % 256);
                    $plaintext .= $decryptedChar;
                }

                return $plaintext;
            }






            function gas($key2) {
                $key2 = strtoupper(preg_replace('/[^A-Za-z]/', '', str_replace('J', 'I', $key2)));
                $keyWithoutDuplicates = '';
                $usedLetters = array();

                for ($i = 0; $i < strlen($key2); $i++) {
                    $currentLetter = $key2[$i];

                    if ($currentLetter === 'I' && in_array('J', $usedLetters)) {
                        continue;
                    } elseif ($currentLetter === 'J' && in_array('I', $usedLetters)) {
                        continue;
                    } elseif (!in_array($currentLetter, $usedLetters)) {
                        $keyWithoutDuplicates .= $currentLetter;
                        $usedLetters[] = $currentLetter;
                    }
                }

                return $keyWithoutDuplicates;
            }


            $plaintext = strtoupper($_POST['plaintext']);
        $key = $_POST['key'];
        $key2 = gas($_POST['key']);
        $cipherType = $_POST['cipherType'];
        $action = $_POST['action'];
        function generatePlayfairMatrix($key) {
            $matrix = array();
            $alphabet = 'ABCDEFGHIKLMNOPQRSTUVWXYZ';
            $keyLength = strlen($key);

            // Fill the matrix with the letters from the key
            for ($i = 0; $i < $keyLength; $i++) {
                $matrix[$i / 5][$i % 5] = $key[$i];
            }

            // Fill the remaining matrix cells with letters from the alphabet
            $alphabetIndex = 0;

            for ($i = $keyLength; $i < 25; $i++) {
                while (in_array($alphabet[$alphabetIndex], str_split($key))) {
                    $alphabetIndex++;
                }
                $matrix[$i / 5][$i % 5] = $alphabet[$alphabetIndex];
                $alphabetIndex++;
            }

            return $matrix;
        }
        if ($cipherType === 'vigenere') {
            if ($action === 'encrypt') {
                $ciphertext = vigenereEncrypt($plaintext, $key);
            } else {
                $ciphertext = vigenereDecrypt($plaintext, $key);
            }

            echo '<div class="result">';
            echo '<h3>Ciphertext:</h3>';
            echo '<textarea readonly>' . $ciphertext . '</textarea>';
            echo '</div>';
        } elseif ($cipherType === 'playfair') {
            if ($action === 'encrypt') {
                $matrix = generatePlayfairMatrix($key2);
                
                $ciphertext = playfairEncrypt($plaintext, $matrix);
            } else {
                $matrix = generatePlayfairMatrix($key2);

                $ciphertext = playfairDecrypt($plaintext, $matrix);
            }

            echo '<div class="result">';
            echo '<h3>Ciphertext:</h3>';
            echo '<textarea readonly>' . $ciphertext . '</textarea>';
            echo '</div>';
        } elseif ($cipherType === 'extendedVigenere') {
            if (isset($_FILES['file']) && $_FILES['file']['error'] === UPLOAD_ERR_OK) {
                $fileContent = file_get_contents($_FILES['file']['tmp_name']);
                 $originalFileName = $_FILES['file']['name'];


                if ($action === 'encrypt') {
                    $encryptedFileName = 'Enskripsi_' . $originalFileName;

                    $ciphertext = extendedVigenereEncrypt($fileContent, $key);
                } else {
                    $encryptedFileName = 'Deskripsi_' . $originalFileName;

                    $ciphertext = extendedVigenereDecrypt($fileContent, $key);
                }

                $encryptionDirectory = './encrypted_files';
                if (!file_exists($encryptionDirectory)) {
                    mkdir($encryptionDirectory, 0777, true);
                }

                // Prepare file names for download links

                // Save encrypted and decrypted files
                $encryptedFilePath = $encryptionDirectory . '/' . $encryptedFileName;
                file_put_contents($encryptedFilePath, $ciphertext);


                echo '<div class="result">';
                echo '<h3>File has been ' . ($action === 'encrypt' ? 'encrypted' : 'decrypted') . ' successfully!</h3>';
                if ($action === 'encrypt') {
                    echo '<p>Download the encrypted file: <a href="' . $encryptedFilePath . '">' . $encryptedFileName . '</a></p>';
                }
                if ($action === 'decrypt') {
                    echo '<p>Download the decrypted file: <a href="' . $encryptedFilePath . '">' . $encryptedFileName . '</a></p>';
                }
                echo '</div>';
            } else {
                echo '<div class="result">';
                echo '<p style="color: red;">Error uploading the file.</p>';
                echo '</div>';
            }
        }
    }

        ?>
    </div>
</body>
</html>